#!/bin/sh

while true
do
      echo "coprocess"
      sleep 1
done
