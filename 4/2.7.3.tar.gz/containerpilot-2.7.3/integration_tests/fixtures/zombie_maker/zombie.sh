#!/bin/bash
sleep 1 & exec /bin/sleep 2
