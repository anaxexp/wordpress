#!/bin/bash
echo 42
