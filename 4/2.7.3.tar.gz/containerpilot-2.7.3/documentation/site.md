Title: ContainerPilot documentation preview
----

Author: Joyent.com and ContainerPilot contributors

----

Description: This is a preview of ContainerPilot documentation; please see [joyent.com/containerpilot/docs](https://www.joyent.com/containerpilot/docs) for official documentation.

----

Keywords: ContainerPilot, orchestration

----

Copyright: © 2015-(date: Year) [Joyent](http://https.joyent.com/)