Title: Support
----
Text:

ContainerPilot is open source software.

- Bugs should be reported in [Github issues](https://github.com/joyent/containerpilot/issues)
- [Joyent](https://www.joyent.com) customers with paid support plans are eligible for ContainerPilot support via the [normal support channels](https://docs.joyent.com/public-cloud/getting-started/support)
- [Pull requests](https://github.com/joyent/containerpilot/pulls) are welcome; please [see Github issues](https://github.com/joyent/containerpilot/issues) for discussion
